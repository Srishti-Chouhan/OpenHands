# SWE-bench Report
This folder contains the evaluation results of the SWE-bench using the [official evaluation docker containerization](https://github.com/princeton-nlp/SWE-bench/blob/main/docs/20240627_docker/README.md#choosing-the-right-cache_level).

## Summary
- submitted instances: 20
- empty patch instances: 4
- resolved instances: 11
- unresolved instances: 9
- error instances: 0

## Resolved Instances
- [astropy__astropy-12907](output.swebench_eval.logs/instance_astropy__astropy-12907.log)
- [django__django-10914](output.swebench_eval.logs/instance_django__django-10914.log)
- [django__django-11099](output.swebench_eval.logs/instance_django__django-11099.log)
- [django__django-16527](output.swebench_eval.logs/instance_django__django-16527.log)
- [django__django-16595](output.swebench_eval.logs/instance_django__django-16595.log)
- [matplotlib__matplotlib-23314](output.swebench_eval.logs/instance_matplotlib__matplotlib-23314.log)
- [pytest-dev__pytest-7432](output.swebench_eval.logs/instance_pytest-dev__pytest-7432.log)
- [sphinx-doc__sphinx-8721](output.swebench_eval.logs/instance_sphinx-doc__sphinx-8721.log)
- [sympy__sympy-13480](output.swebench_eval.logs/instance_sympy__sympy-13480.log)
- [sympy__sympy-14774](output.swebench_eval.logs/instance_sympy__sympy-14774.log)
- [sympy__sympy-24213](output.swebench_eval.logs/instance_sympy__sympy-24213.log)

## Unresolved Instances
- [astropy__astropy-14182](output.swebench_eval.logs/instance_astropy__astropy-14182.log)
- [django__django-14238](output.swebench_eval.logs/instance_django__django-14238.log)
- [django__django-14534](output.swebench_eval.logs/instance_django__django-14534.log)
- [matplotlib__matplotlib-23476](output.swebench_eval.logs/instance_matplotlib__matplotlib-23476.log)
- [psf__requests-2317](output.swebench_eval.logs/instance_psf__requests-2317.log)
- [pydata__xarray-4094](output.swebench_eval.logs/instance_pydata__xarray-4094.log)
- [pylint-dev__pylint-7080](output.swebench_eval.logs/instance_pylint-dev__pylint-7080.log)
- [scikit-learn__scikit-learn-10508](output.swebench_eval.logs/instance_scikit-learn__scikit-learn-10508.log)
- [sympy__sympy-13031](output.swebench_eval.logs/instance_sympy__sympy-13031.log)

## Error Instances

## Empty Patch Instances
- [django__django-14238](output.swebench_eval.logs/instance_django__django-14238.log)
- [psf__requests-2317](output.swebench_eval.logs/instance_psf__requests-2317.log)
- [pydata__xarray-4094](output.swebench_eval.logs/instance_pydata__xarray-4094.log)
- [pylint-dev__pylint-7080](output.swebench_eval.logs/instance_pylint-dev__pylint-7080.log)

## Incomplete Instances
